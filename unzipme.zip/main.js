const CSVToJSON = require("csvtojson");
const JSONToCSV = require("json2csv").parse;
const FileSystem = require("fs");

CSVToJSON().fromFile("./input.csv").then(source => {
    console.log(source);
    for (let i=0; i < source.length; i++) {
        email = '';
        email += source[i].Last_Name;
        email += source[i].First_Name[0];
        email += source[i].First_Name[1];
        email += source[i].First_Name[2];
        email += '@gilbertschool.org';
        source[i].Email = email;
        console.log(source[i]);
        console.log(i);
    }


    var csv = JSONToCSV(source, { fields: ["Last_Name", "First_Name", "Email" ]});
    FileSystem.writeFileSync("./output.csv", csv);
});